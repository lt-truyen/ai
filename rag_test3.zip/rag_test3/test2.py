# RAG local: Excel -> Embedding (sentence-transformers) -> FAISS -> Gemma 2B (Ollama)
# pip install pandas openpyxl sentence-transformers faiss-cpu
# ollama pull gemma:2b
# setx PYTHONUTF8 1
import pandas as pd
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
from pathlib import Path
import subprocess

# Cấu hình
DATA_DIR = Path("data_excels")
EMB_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"  # nhẹ, đủ tốt
TOP_K = 5
LLM_NAME = "gemma:2b"

# 1) Excel -> chunks
def row_to_text2(row, columns, meta):
    parts = []
    for col in columns:
        val = row.get(col, "")
        if val is None or (isinstance(val, float) and pd.isna(val)):
            continue
        val = str(val).strip()
        if not val:
            continue
        parts.append(f"{col}: {val}")
    text = "; ".join(parts)
    return f"[file={meta['file']}; sheet={meta['sheet']}; row={meta['row']}] {text}"

# 2) Đọc & chuyển đổi Excel thành chunks
def row_to_text(row, columns, meta):
    parts = []
    primary_key = None

    for col in columns:
        val = row.get(col, "")
        if pd.isna(val):
            continue
        val = str(val).strip()
        if not val:
            continue

        # Nếu có cột "Mã sản phẩm", giữ lại làm metadata
        if col.lower().strip() == "mã sản phẩm":
            primary_key = val

        parts.append(f"{col}: {val}")

    text = "; ".join(parts)

    # Thêm metadata trong dạng header để LLM dễ ngữ cảnh
    header = f"[file={meta['file']}; sheet={meta['sheet']}; row={meta['row']}]"
    if primary_key:
        header += f" [Mã sản phẩm={primary_key}]"

    return f"{header} {text}"

def excel_to_chunks(file_path: Path):
    chunks = []
    xls = pd.ExcelFile(file_path)
    for sheet in xls.sheet_names:
        df = xls.parse(sheet_name=sheet, dtype=str).fillna("")
        columns = list(df.columns)
        for idx, row in df.iterrows():
            meta = {"file": file_path.name, "sheet": sheet, "row": idx}
            chunks.append(row_to_text(row.to_dict(), columns, meta))
    return chunks

all_chunks = []
for fp in DATA_DIR.glob("*.xlsx"):
    all_chunks.extend(excel_to_chunks(fp))

if not all_chunks:
    raise RuntimeError("Không tìm thấy dữ liệu Excel trong thư mục data_excels/*.xlsx")

# 2) Embedding
emb_model = SentenceTransformer(EMB_MODEL_NAME)
embeddings = emb_model.encode(all_chunks, convert_to_numpy=True, normalize_embeddings=True)

# 3) FAISS index (cosine via inner product with normalized vectors)
dim = embeddings.shape[1]
index = faiss.IndexFlatIP(dim)
index.add(embeddings)
id_to_text = {i: txt for i, txt in enumerate(all_chunks)}

def retrieve(query: str, k: int = TOP_K):
    q_emb = emb_model.encode([query], convert_to_numpy=True, normalize_embeddings=True)
    scores, ids = index.search(q_emb, k)
    return [(id_to_text[i], float(scores[0][j])) for j, i in enumerate(ids[0])]

# 4) Gọi LLM Gemma 2B qua Ollama (ép UTF-8)
def ollama_chat(prompt: str, model: str = LLM_NAME):
    cmd = ["ollama", "run", model]
    p = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
    )
    out, err = p.communicate(prompt)
    if err:
        # Không dừng ngay: nhiều model log cảnh báo; chỉ trả về out để xem kết quả
        pass
    return out

def build_prompt(query: str, contexts):
    context_block = "\n\n".join([f"- {c[0]}" for c in contexts])
    return f"""Bạn là trợ lý phân tích Excel.
Câu hỏi: {query}

Nguồn dữ liệu liên quan:
{context_block}

Yêu cầu:
- Trả lời chính xác, trích dẫn [file=...; sheet=...; row=...] với mỗi luận điểm.
- Nếu dữ liệu chưa đủ, nói rõ chỗ thiếu và đề xuất cột/sheet cần kiểm tra thêm.
- Không suy đoán vượt quá thông tin có trong nguồn.
- Nếu yêu cầu nhiều sản phẩm thì liêt kê rõ ràng sản phẩm được tìm thấy
- Mô tả dạng bảng nếu có thể.
"""

if __name__ == "__main__":
    query = "Doanh thu của sản phẩm E và D?"
    ctx = retrieve(query, k=TOP_K)
    prompt = build_prompt(query, ctx)
    answer = ollama_chat(prompt)
    print(answer)